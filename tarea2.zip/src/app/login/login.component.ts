import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  title = 'tarea_2_log_in';
  datos = {
    "email": "test@test.com",
    "password": "password"
  }
  //Escribir codigo aquí :D
}
