import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss', './register/register.component.scss']
})
export class AppComponent {
  title = 'tarea_2';
  //Escribir codigo aquí :D
}
